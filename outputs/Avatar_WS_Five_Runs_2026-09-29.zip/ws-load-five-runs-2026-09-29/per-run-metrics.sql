WITH ranked AS (
 SELECT *,ROW_NUMBER() OVER (PARTITION BY group_id,run,scenario ORDER BY latency_ms,session,turn) AS rn,
 COUNT(*) OVER (PARTITION BY group_id,run,scenario) AS n
 FROM main.ws_answers WHERE status='ok'
) SELECT group_id,run,scenario,COUNT(*) AS answers,AVG(latency_ms)/1000.0 AS meanSeconds,
 MAX(CASE WHEN rn=CAST((n*95+99)/100 AS INTEGER) THEN latency_ms END)/1000.0 AS p95Seconds,
 MAX(latency_ms)/1000.0 AS maxSeconds
 FROM ranked GROUP BY group_id,run,scenario ORDER BY group_id,run,scenario;