// Bounded, local-only follow-up after the official Windows overflow check failed.
const fs=require('fs');
const path=require('path');
const {pathToFileURL}=require('url');
const {chromium}=require('playwright');
(async()=>{
 const out=__dirname;const artifact=JSON.parse(fs.readFileSync(path.join(out,'artifact.json'),'utf8'));
 const official=await import(pathToFileURL('C:/Users/Propawn/.codex/plugins/cache/openai-curated-remote/data-analytics/0.2.10-13ceeea1f599/skills/build-report/scripts/verify_portable_artifact.mjs'));
 const structure=official.verifyPortableArtifactStructure({artifactPath:path.join(out,'artifact.json'),htmlPath:path.join(out,'report.html')});
 const browser=await chromium.launch({headless:true});const checks=[];
 try {
  for(const scheme of ['light','dark']) {
   const context=await browser.newContext({viewport:{width:1440,height:1000},colorScheme:scheme,reducedMotion:'reduce'});
   const page=await context.newPage();const errors=[],external=[];
   page.on('pageerror',e=>errors.push(String(e)));
   page.on('request',r=>{if(/^https?:/.test(r.url()))external.push(r.url());});
   await page.goto(pathToFileURL(path.join(out,'report.html')).href,{waitUntil:'load'});
   await page.locator('.recharts-wrapper').first().waitFor({state:'visible',timeout:15000});
   const charts=page.locator('.recharts-wrapper');
   if(await charts.count()!==3)throw new Error('Expected three visible chart wrappers');
   const geometry=[];
   for(let i=0;i<3;i++) {
    const chart=charts.nth(i);await chart.scrollIntoViewIfNeeded();await page.waitForTimeout(400);
    const rows=artifact.snapshot.datasets[['stage-old','prod-old','dev-new'][i]+'-runs'];
    const series=chart.locator('.recharts-bar');const scales=[];
    for(let j=0;j<4;j++) {
     const bars=await series.nth(j).locator('.recharts-rectangle').evaluateAll(es=>es.map(e=>({name:e.getAttribute('name'),height:Number(e.getAttribute('height'))})));
     if(bars.length!==5)throw new Error('Expected five visible bars per scenario');
     const expected=rows.filter(r=>r.scenarioLabel===bars[0].name);
     bars.forEach((bar,k)=>scales.push(bar.height/expected[k].meanSeconds));
    }
    if(Math.max(...scales)-Math.min(...scales)>.001)throw new Error('Bar heights do not share the expected numeric scale');
    geometry.push({chart:i+1,visibleBars:scales.length,pixelsPerSecondMin:Math.min(...scales),pixelsPerSecondMax:Math.max(...scales)});
    await chart.locator('xpath=ancestor::*[contains(@class,"chart-frame")][1]').screenshot({path:path.join(out,`report-${scheme}-chart-${i+1}.png`)});
   }
   const desktop=await page.evaluate(()=>({width:innerWidth,clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth,headings:[...document.querySelectorAll('h2')].filter(e=>e.getBoundingClientRect().height).map(e=>e.textContent)}));
   await page.setViewportSize({width:390,height:844});
   await page.waitForTimeout(300);
   const narrow=await page.evaluate(()=>({width:innerWidth,clientWidth:document.documentElement.clientWidth,scrollWidth:document.documentElement.scrollWidth}));
   checks.push({scheme,desktop,narrow,charts:3,geometry,pageErrors:errors,externalRequests:external});
   if(errors.length||external.length)throw new Error('Unexpected page error or external request');
   await context.close();
  }
 } finally {await browser.close();}
 const result={officialStructure:structure,followupBrowser:'Installed Playwright Chromium, separate local headless context; does not replace the failed official Windows scrollbar check.',checks};
 fs.writeFileSync(path.join(out,'report-inspection.json'),JSON.stringify(result,null,2));
 console.log(JSON.stringify(result));
})().catch(e=>{console.error(e);process.exitCode=1;});
