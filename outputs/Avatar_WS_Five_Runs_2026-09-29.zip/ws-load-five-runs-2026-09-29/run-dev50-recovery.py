"""Run separately identified recoveries for the two unsent dev 50-session cohorts."""
import importlib.util,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('campaign',OUT/'run-campaign.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.state['status']=='complete'
assert any(x['group']=='stage-old' and x['run']==6 and x['exitCode']==0 for x in m.state.get('supplementalAttempts',[]))
try:
 for run in [6,7]:
  e=m.env_for('dev',run,'parallel');e['WS_LOAD_SCENARIOS']='parallel-50'
  root=m.ROOT/'test-results/ws-load'/e['WS_LOAD_RUN_ID'];assert not root.exists()
  m.emit(status='running',environment='dev',group='dev-new',run=run,mode='supplemental-parallel',progress=None,error=None)
  result=m.child('playwright.ws-load.config.ts',e,f'dev-r{run}-supplemental-parallel.log')
  m.freeze('dev',run,'parallel',root,expected=1)
  m.state.setdefault('supplementalAttempts',[]).append({'group':'dev-new','run':run,'mode':'parallel','scenarios':['parallel-50'],'exitCode':result,'atUtc':m.now()})
  if result:raise RuntimeError('Dev recovery cohort failed; retained without an automatic additional rerun.')
 m.emit(status='complete',finishedAtUtc=m.now(),supplementalAttempts=m.state['supplementalAttempts'])
except BaseException as exc:
 m.state['errors'].append({'atUtc':m.now(),'error':str(exc)});m.emit(status='stopped',error=str(exc));sys.exit(1)
