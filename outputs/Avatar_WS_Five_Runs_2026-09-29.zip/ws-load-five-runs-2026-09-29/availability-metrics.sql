WITH cohorts AS (
 SELECT group_id,run,scenario,COUNT(*) AS planned,
 SUM(CASE WHEN status='ok' THEN 1 ELSE 0 END) AS complete,
 SUM(CASE WHEN status='skipped' THEN 1 ELSE 0 END) AS skipped
 FROM main.ws_answers WHERE group_id<>'dev-old-reference'
 GROUP BY group_id,run,scenario
) SELECT group_id,
 SUM(CASE WHEN run<=5 AND complete=planned THEN 1 ELSE 0 END) AS originalComplete,
 SUM(CASE WHEN run<=5 THEN 1 ELSE 0 END) AS originalAttempts,
 SUM(CASE WHEN run<=5 THEN skipped ELSE 0 END) AS unsent,
 SUM(CASE WHEN run>5 THEN complete ELSE 0 END) AS recoveryReplies
 FROM cohorts GROUP BY group_id ORDER BY group_id;