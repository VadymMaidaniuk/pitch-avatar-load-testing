import json
from pathlib import Path
p=Path(__file__).resolve().parent
def read(f):return json.loads((p/f).read_text(encoding='utf-8'))
s=read('state.json')
print(json.dumps({k:s.get(k) for k in ['status','group','run','mode','progress','finishedMatrices','updatedAtUtc','error']},ensure_ascii=False))
if (p/'pending-review.json').exists():
 pending=read('pending-review.json')
 if pending:print(json.dumps(pending,ensure_ascii=False,indent=2))
if s['finishedMatrices']:
 last=s['finishedMatrices'][-1];group,run=last.rsplit('-r',1)
 f=p/'snapshots'/group/('run-'+run)/'parallel-50.json'
 if f.exists():
  d=json.loads(f.read_text(encoding='utf-8'))
  print(json.dumps({'lastCompleteMatrix':last,'parallel50':d['summary']['fullText']},ensure_ascii=False))
