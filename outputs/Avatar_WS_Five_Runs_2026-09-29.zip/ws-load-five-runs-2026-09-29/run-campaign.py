"""Run the explicitly authorized 12 additional complete matrices, sequentially.
Uses the original unchanged Playwright tests. Never retries measured questions.
Unknown answer texts require a local evidence review before the next phase.
"""
import hashlib,json,os,queue,shutil,subprocess,sys,threading,time
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
PLAN=json.loads((OUT/'plan.json').read_text(encoding='utf-8'))
URLS={'stage':'https://slides-staging.pitchavatar.com/wwqbg','prod':'https://slides.pitchavatar.com/suwoy','dev':'https://slides-dev.pitchavatar.com/1eipe'}
GROUPS={'stage':'stage-old','prod':'prod-old','dev':'dev-new'}
def now():return datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(name,data):
 p=OUT/name;temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(p)
def digest(q,t):return hashlib.sha256(f'{q}\n{t}'.encode()).hexdigest()
state=read(OUT/'state.json') if (OUT/'state.json').exists() else {'startedAtUtc':now(),'completedPhases':[],'finishedMatrices':[],'errors':[]}
def emit(**fields):
 state.update(fields,updatedAtUtc=now());save('state.json',state)
 print(json.dumps({k:v for k,v in fields.items() if k!='completedPhases'}),flush=True)
def pins():
 for f in PLAN['pinnedFiles']:
  if hashlib.sha256((ROOT/f['path']).read_bytes()).hexdigest()!=f['sha256']:raise RuntimeError('Pinned workload/client file changed: '+f['path'])
def env_for(env,run=None,mode=None):
 e=os.environ.copy()
 for k in list(e):
  if k.startswith('WS_LOAD_') or k.startswith('WS_PREFLIGHT_'):e.pop(k)
 e.update(CHAT_ENV=env,WS_LOAD_CHAT_URL=URLS[env],WS_LOAD_QUESTIONS_FILE=str(OUT/'ws-load-aster-questions.json'),WS_LOAD_PARALLEL_QUESTIONS='2',WS_LOAD_LANGUAGE='en',WS_LOAD_SETUP_TIMEOUT_MS='90000',WS_LOAD_CONNECT_TIMEOUT_MS='30000',WS_LOAD_RESPONSE_TIMEOUT_MS='60000',WS_LOAD_SETUP_CONCURRENCY='1',WS_LOAD_SETUP_ATTEMPTS='3',WS_LOAD_SETTLE_MS='1000',WS_LOAD_REQUIRE_CACHE_DISABLED='0',PYTHONIOENCODING='utf-8')
 if mode:
  e['WS_LOAD_SCENARIOS']='chain-1x25' if mode=='chain' else 'parallel-10,parallel-20,parallel-50'
  e['WS_LOAD_RUN_ID']=f'2026-09-29-five-{env}-r{run}-{mode}'
  if mode=='parallel':e['WS_LOAD_PARALLEL_QUESTION_IDS']='8,14'
 else:e['WS_PREFLIGHT_RUN_ID']=f'2026-09-29-five-runs-{env}-preflight'
 return e
def child(config,e,logname):
 pins();logs=OUT/'logs';logs.mkdir(exist_ok=True)
 proc=subprocess.Popen(['node',str(ROOT/'node_modules/@playwright/test/cli.js'),'test','--config='+config],cwd=ROOT,env=e,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1)
 q=queue.Queue()
 def reader():
  for line in proc.stdout:q.put(line)
  q.put(None)
 threading.Thread(target=reader,daemon=True).start()
 with (logs/logname).open('w',encoding='utf-8') as log:
  while True:
   if (OUT/'STOP').exists():
    subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    raise RuntimeError('Campaign stopped by local STOP marker')
   try:line=q.get(timeout=.5)
   except queue.Empty:continue
   if line is None:break
   log.write(line);log.flush()
   if line.startswith('{'):
    try:item=json.loads(line)
    except json.JSONDecodeError:continue
    if isinstance(item,dict) and item.get('phase') in ['preparing','ready','reply']:
     emit(status='running',progress=item)
 return proc.wait()
def grade(items,context):
 pending={};ledger=read(OUT/'reviewed-answers.json');key=read(OUT/'ws-load-aster-answer-key.json')
 for qid,text,status in items:
  # Preserve transport failures/skipped requests as outcomes. Never replace them
  # with a rerun or misclassify missing text as a correct answer.
  if status!='ok':continue
  h=digest(qid,text)
  if ledger.get(h,{}).get('assessment')!='correct':pending[h]={'sourceQuestionId':qid,'text':text,'expected':key['questions'][qid-1]['expectedAnswer'],'context':context}
 if not pending:return
 save('pending-review.json',pending);emit(status='awaiting_answer_review',reviewContext=context,unreviewed=len(pending))
 while pending:
  if (OUT/'STOP').exists():raise RuntimeError('Stopped during answer review')
  time.sleep(1);ledger=read(OUT/'reviewed-answers.json')
  rejected=[h for h in pending if ledger.get(h,{}).get('assessment') in ['incorrect','refusal']]
  if rejected:raise RuntimeError('Answer review rejected content in '+context)
  pending={h:v for h,v in pending.items() if ledger.get(h,{}).get('assessment')!='correct'}
 save('pending-review.json',{});emit(status='running',unreviewed=0)
def preflight(env):
 e=env_for(env);root=ROOT/'test-results/ws-preflight'/e['WS_PREFLIGHT_RUN_ID'];found=list(root.glob('*/preflight.json'))
 if not found:
  emit(status='preflight',environment=env,group=GROUPS[env],run=None,mode='preflight')
  code=child('playwright.ws-preflight.config.ts',e,f'{env}-preflight.log')
  found=list(root.glob('*/preflight.json'))
  if code or len(found)!=1:raise RuntimeError('Preflight failed for '+env)
 d=read(found[0]);baseline=read(OUT/'snapshots'/GROUPS[env]/'run-1/chain-1x25.json')
 if d['metadata']['avatar']!=baseline['sessions'][0]['avatar']:raise RuntimeError('Avatar metadata changed for '+env)
 dest=OUT/'preflight';dest.mkdir(exist_ok=True);shutil.copyfile(found[0],dest/(env+'.json'))
 grade([(i+1,x['reply']['text'],x['reply']['status']) for i,x in enumerate(d['replies'])],env+' preflight')
 if len(d['replies'])!=3:raise RuntimeError('Missing control answers')
def freeze(env,run,mode,runroot,expected=None):
 group=GROUPS[env];files=list(runroot.glob('artifacts/*/metrics/results.json'));expected=expected if expected is not None else (1 if mode=='chain' else 3)
 if len(files)!=expected:raise RuntimeError('Missing scenario reports for '+group)
 items=[]
 for p in files:
  d=read(p);scenario=d['scenario']['name'];base=read(OUT/'snapshots'/group/'run-1'/(scenario+'.json'))
  for k in ['questionsSha256','comparableQuestionCasesSha256','requestedLanguageId','parallelQuestionIds','setupTimeoutMs','setupConcurrency','setupAttemptLimit','connectTimeoutMs','responseTimeoutMs','startupQuietMs','requireCacheDisabled','retries','percentileMethod']:
   if d['settings'][k]!=base['settings'][k]:raise RuntimeError('Settings mismatch: '+k)
  if any(s['avatar'] is not None and s['avatar']!=base['sessions'][0]['avatar'] for s in d['sessions']):raise RuntimeError('Avatar metadata changed within '+group)
  dest=OUT/'snapshots'/group/f'run-{run}'/(scenario+'.json');dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.exists() and dest.read_bytes()!=p.read_bytes():raise RuntimeError('Refusing to overwrite different frozen results')
  shutil.copyfile(p,dest)
  entry={'group':group,'environment':env,'codeLabel':'new' if env=='dev' else 'old','run':run,'scenario':scenario,'source':p.relative_to(ROOT).as_posix(),'snapshot':dest.relative_to(OUT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
  inventory=read(OUT/'inventory.json') if (OUT/'inventory.json').exists() else []
  inventory=[x for x in inventory if x['snapshot']!=entry['snapshot']]+[entry];save('inventory.json',inventory)
  items.extend((q['sourceQuestionId'],(q['reply'] or {}).get('text',''),q['status']) for q in d['questions'])
  print(json.dumps({'group':group,'run':run,'scenario':scenario,'summary':{k:d['summary'][k] for k in ['plannedQuestions','successfulQuestions','failedQuestions','skippedQuestions','peakInFlight','fullText']}}),flush=True)
 grade(items,f'{group} run {run} {mode}')
def main():
 for env in ['stage','prod','dev']:
  preflight(env)
  for run in [2,3,4,5]:
   for mode in ['chain','parallel']:
    phase=f'{GROUPS[env]}-r{run}-{mode}'
    if phase in state['completedPhases']:continue
    emit(status='running',environment=env,group=GROUPS[env],run=run,mode=mode,progress=None)
    e=env_for(env,run,mode);runroot=ROOT/'test-results/ws-load'/e['WS_LOAD_RUN_ID']
    if runroot.exists():
     raise RuntimeError('Existing unfinished run directory: inspect it before resuming '+phase)
    code=child('playwright.ws-load.config.ts',e,phase+'.log')
    freeze(env,run,mode,runroot)
    if code:
     state.setdefault('failedPhases',[]).append({'phase':phase,'exitCode':code,'atUtc':now(),'note':'Original failed outcome retained; no measured-request retries.'})
     emit(status='running',failedPhases=state['failedPhases'])
    state['completedPhases'].append(phase);emit(status='running',completedPhases=state['completedPhases'])
   matrix=f'{GROUPS[env]}-r{run}'
   if matrix not in state['finishedMatrices']:state['finishedMatrices'].append(matrix)
   emit(status='running',finishedMatrices=state['finishedMatrices'])
  emit(status='group_complete',group=GROUPS[env],completedRuns=5)
 emit(status='complete',finishedAtUtc=now(),additionalMeasuredQuestions=2220)
if __name__=='__main__':
 try:main()
 except BaseException as exc:
  state['errors'].append({'atUtc':now(),'error':str(exc)});emit(status='stopped',error=str(exc));sys.exit(1)
