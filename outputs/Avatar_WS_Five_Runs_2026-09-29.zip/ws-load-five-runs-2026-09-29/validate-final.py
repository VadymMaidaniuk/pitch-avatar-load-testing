"""Offline final evidence checks; sends no requests and changes no raw results."""
import csv,hashlib,json
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
def read(name):return json.loads((OUT/name).read_text(encoding='utf-8'))
s=read('summary.json');plan=read('plan.json')
assert s['complete'] and s['targetReplicationsReached'] and not s['unknownAnswers']
addendum=read('plan-addendum.json');extra=addendum['additionalPlannedQuestions'];extra_scenarios=addendum['supplementalScenarios']
assert s['totals']==dict(planned=2775+extra,complete=2775,correct=2775,failed=0,skipped=extra,unreviewed=0)
assert len(s['sources'])==64+extra_scenarios
for item in plan['pinnedFiles']:
 assert hashlib.sha256((ROOT/item['path']).read_bytes()).hexdigest()==item['sha256']
main=[r for r in s['perRun'] if r['group']!='dev-old-reference']
successful=[r for r in main if r['complete']==r['planned']]
failed=[r for r in main if r['complete']!=r['planned']]
assert len(successful)==60 and len(failed)==extra_scenarios
assert all(r['complete']==r['failed']==0 and r['skipped']==r['planned'] for r in failed)
assert all(r['peak']==r['sessions']==r['readySessions'] for r in successful)
assert all(r['allFirstSentBeforeFirstReplyMs']>0 for r in successful)
intervals=sorted((datetime.fromisoformat(r['startedAtUtc']),datetime.fromisoformat(r['finishedAtUtc']),r['group'],r['run'],r['scenario']) for r in main)
assert all(a[1]<=b[0] for a,b in zip(intervals,intervals[1:])), 'Overlapping scenario execution'
completion_events=Counter();rows=[]
for entry in s['sources']:
 d=read(entry['snapshot'])
 for q in d['questions']:
  if q['status']=='ok':completion_events[(q['reply']['completionEvent'],q['reply']['chunks'])]+=1
for group in ['stage-old','prod-old','dev-new']:
 cases=[r for r in main if r['group']==group];original=[r for r in cases if r['run']<=5];recovery=[r for r in cases if r['run']>5]
 assert len(original)==20 and sum(r['complete'] for r in cases)==925
 rows.append(dict(group=group,originalScenarioAttempts=len(original),originalCompletedScenarios=sum(r['complete']==r['planned'] for r in original),originalCompleteMatrices=','.join(map(str,s['completeMeasurementGroups'][group])),originalPlannedQuestions=sum(r['planned'] for r in original),originalCompleteReplies=sum(r['complete'] for r in original),originalUnsentQuestions=sum(r['skipped'] for r in original),recoveryScenarioAttempts=len(recovery),recoveryCompleteReplies=sum(r['complete'] for r in recovery),allCompleteReplies=sum(r['complete'] for r in cases),setupFailedAttempts=sum(r['setupFailedAttempts'] for r in cases)))
with (OUT/'availability.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
result=dict(validatedAtUtc=datetime.now(timezone.utc).isoformat(),totals=s['totals'],snapshotFiles=len(s['sources']),completeMainScenarioAttempts=len(successful),failedUnsentMainScenarioAttempts=len(failed),pinnedFilesUnchanged=len(plan['pinnedFiles']),scenarioTimeIntervalsDoNotOverlap=True,successfulPeakEqualsRequestedSessions=True,allFirstWavesSentBeforeAnyFirstReply=True,completionEventsIncludingOldDev=[dict(event=k[0],chunks=k[1],count=v) for k,v in completion_events.items()],availability=rows,limitations=['Latency conditional on a successfully started cohort; retained failed setup attempts are separate.','A unique question suffix does not prove cache miss.','Backend version labels are user-reported.'])
(OUT/'validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
