"""Record only explicitly supplied hashes after reading their answer and expected fact."""
import json,sys
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent
pending=json.loads((out/'pending-review.json').read_text(encoding='utf-8'))
ledger=json.loads((out/'reviewed-answers.json').read_text(encoding='utf-8'))
assert sys.argv[1:],'Supply only the exact hashes that were explicitly reviewed'
assert all(h in pending for h in sys.argv[1:])
for h in sys.argv[1:]:ledger[h]={**pending[h],'assessment':'correct','reviewMethod':'Explicit semantic comparison of displayed answer to its corresponding expected fact','reviewedAtUtc':datetime.now(timezone.utc).isoformat()}
temp=out/'reviewed-answers.json.tmp';temp.write_text(json.dumps(ledger,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(out/'reviewed-answers.json')
print(f'Recorded explicit review of {len(sys.argv)-1} answer variants.')
