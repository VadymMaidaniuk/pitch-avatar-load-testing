WITH ranked AS (
  SELECT *,ROW_NUMBER() OVER (PARTITION BY group_id,scenario ORDER BY latency_ms,run,session,turn) AS rn,
  COUNT(*) OVER (PARTITION BY group_id,scenario) AS n FROM main.ws_answers WHERE status='ok'
 ) SELECT group_id AS groupId,environment,code_label AS codeLabel,scenario,sessions,COUNT(*) AS complete,
 AVG(latency_ms) AS meanMs,
 MAX(CASE WHEN rn=CAST((n*50+99)/100 AS INTEGER) THEN latency_ms END) AS p50Ms,
 MAX(CASE WHEN rn=CAST((n*95+99)/100 AS INTEGER) THEN latency_ms END) AS p95Ms,MAX(latency_ms) AS maxMs
 FROM ranked GROUP BY group_id,environment,code_label,scenario,sessions ORDER BY group_id,sessions;