"""Freeze the completed local evidence package, with file and archive SHA256."""
import hashlib,json,zipfile
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
def read(name):return json.loads((OUT/name).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
state=read('state.json');summary=read('summary.json')
assert state['status']=='complete' and summary['complete']
assert summary['totals']['planned']==2775+read('plan-addendum.json')['additionalPlannedQuestions'] and summary['targetReplicationsReached'] and not summary['unknownAnswers']
assert len(state['finishedMatrices'])==12 and len(set(state['finishedMatrices']))==12
assert all(summary['completeGroups'][g]==[1,2,3,4,5] for g in ['stage-old','prod-old','dev-new'])
assert (OUT/'report.html').exists() and (OUT/'campaign.ipynb').exists() and (OUT/'validation.json').exists()
assert not read('pending-review.json') if (OUT/'pending-review.json').exists() else True
for item in read('plan.json')['snapshots']+read('inventory.json'):
 assert sha(OUT/item['snapshot'])==item['sha256']
for item in read('plan.json')['pinnedFiles']:
 assert sha(OUT/'client-source'/item['path'])==item['sha256']
preflight_count=0;control_ids=set();failed_controls=[]
for path in sorted((OUT/'preflight').glob('*.json')):
 report=json.loads(path.read_text(encoding='utf-8'));env=report['environment'];controls=report['replies']
 if not report['metadata']['ready']:
  assert not controls;failed_controls.append({'file':path.name,'error':report['metadata']['error']});continue
 assert len(controls)==3
 for i,q in enumerate(controls):
  reply=q['reply'];assert reply['status']=='ok'
  key=hashlib.sha256(f'{i+1}\n{reply["text"]}'.encode()).hexdigest()
  assert read('reviewed-answers.json')[key]['assessment']=='correct'
  identity=(env,reply['messageId']);assert identity not in control_ids;control_ids.add(identity)
 preflight_count+=len(controls)
assert preflight_count==15 and len(failed_controls)==1
readme='''# Frozen WebSocket load-test baseline — 2026-09-29

Stage OLD and prod OLD: five planned matrices each (run 1 on September 28, runs 2–5 on September 29). Stage run 5 had failed preparation for 10/20/50; its 160 unsent questions are retained. Supplemental stage run 6 repeats these cohorts after prod/dev. Prod run 4 parallel-50 and run 5 failed DNS lookup, leaving 285 unsent questions; prod run 6 and run 7 parallel-50 provide the missing completed latency measurements. All failures remain.
Dev NEW: five completed measurements per scenario on September 29, including a separately identified recoveries for runs 2 and 5 parallel-50. Dev OLD: one separate historical matrix on September 28.
Labels OLD/NEW are user-reported backend state; see versionEvidence in plan.json/summary.json. The runner git hash is not a backend deployment hash.

Each matrix = 1×25 sequential questions, then 10×2, 20×2, 50×2 independent sessions.
Additional measured responses: 2220. Main collection: 2775 received out of 3420 planned, including 160 unsent stage questions, 285 unsent prod questions and 200 unsent dev questions. Dev run 2 parallel-50 detected a closed prepared socket before the common start; dev run 6 repeats that cohort. Dev run 5 parallel-50 failed API login preparation, and dev run 7 repeats it. There are 925 received per group; five completed latency measurements per scenario. No group had five error-free original full matrices. This denominator includes recovery attempts and is not a production availability estimate.
Old-dev reference: 185 additional records. answers.csv includes all 3605 planned records, distinguished by group.
Fifteen successful preflight replies (including fresh controls after the incidents) are separate and excluded from latency metrics. The failed dev DNS preflight sent no questions.

Open report.html for the report; summary.md is the lightweight text alternative.
Import per-run.csv, pooled.csv, answers.csv or availability.csv into Google Sheets as separate sheets (UTF-8). validation.json records the final independent checks.
campaign.ipynb is an executed standard-library notebook. Run from this directory or the repository root.
Recompute with `python -X utf8 analyze.py` from this directory; build-report.py creates the canonical report payload/notebook.
Do not rerun run-campaign.py without a new task-specific output directory and an explicitly planned comparison.

Snapshots and client-source are preserved with SHA256. plan.json stores original run-1 sources and pinned client files;
inventory.json stores the 48 originally planned added scenario sources plus 10 supplemental stage/prod/dev sources. stage-incident.json and setup-failures.csv preserve preparation failures. manifest.sha256.json covers all archive files except itself.
The adjacent .zip.sha256 file hashes the entire ZIP. No outliers were removed or repeated to replace them.

Latency is websocket question send → complete assistant text, excluding setup and media.
Pooled p95 uses individual responses, never averages of p95s. Per-run results expose variability.
Client cacheEnabled=true does not identify cache hits; a nonce does not establish uncached LLM generation.
These are short 2-question bursts, not a sustained 50-user capacity/SLA test.
Compare stage/prod against themselves after a later deployment; cross-environment differences are not causal effects.
'''
(OUT/'README.md').write_text(readme,encoding='utf-8')
files=sorted(p for p in OUT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='manifest.sha256.json' and not p.name.endswith('.tmp'))
manifest={'frozenAtUtc':datetime.now(timezone.utc).isoformat(),'completeGroups':summary['completeGroups'],'totals':summary['totals'],'additionalMeasuredQuestions':summary['totals']['complete']-555,'additionalPlannedQuestions':summary['totals']['planned']-555,'completeScenarioReplications':summary['completeScenarioReplications'],'freshControlRepliesExcluded':preflight_count,'failedPreflightControls':failed_controls,'completeOriginalMatrices':summary['completeMeasurementGroups'],'oldDevReferenceMatrices':1,'files':[{'path':p.relative_to(OUT).as_posix(),'size':p.stat().st_size,'sha256':sha(p)} for p in files]}
(OUT/'manifest.sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
dest=ROOT/'outputs';dest.mkdir(exist_ok=True)
archive=dest/'Avatar_WS_Five_Runs_2026-09-29.zip'
assert not archive.exists(),'Refusing to overwrite a previously frozen archive'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for p in files+[OUT/'manifest.sha256.json']:z.write(p,OUT.name+'/'+p.relative_to(OUT).as_posix())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for entry in manifest['files']:
  assert hashlib.sha256(z.read(OUT.name+'/'+entry['path'])).hexdigest()==entry['sha256']
archive.with_suffix('.zip.sha256').write_text(sha(archive)+'  '+archive.name+'\n',encoding='utf-8')
print(json.dumps({'archive':str(archive),'size':archive.stat().st_size,'sha256':sha(archive),'files':len(files)+1},indent=2))
