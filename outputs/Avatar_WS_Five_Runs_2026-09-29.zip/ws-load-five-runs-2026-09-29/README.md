# Frozen WebSocket load-test baseline — 2026-09-29

Stage OLD and prod OLD: five planned matrices each (run 1 on September 28, runs 2–5 on September 29). Stage run 5 had failed preparation for 10/20/50; its 160 unsent questions are retained. Supplemental stage run 6 repeats these cohorts after prod/dev. Prod run 4 parallel-50 and run 5 failed DNS lookup, leaving 285 unsent questions; prod run 6 and run 7 parallel-50 provide the missing completed latency measurements. All failures remain.
Dev NEW: five completed measurements per scenario on September 29, including a separately identified recoveries for runs 2 and 5 parallel-50. Dev OLD: one separate historical matrix on September 28.
Labels OLD/NEW are user-reported backend state; see versionEvidence in plan.json/summary.json. The runner git hash is not a backend deployment hash.

Each matrix = 1×25 sequential questions, then 10×2, 20×2, 50×2 independent sessions.
Additional measured responses: 2220. Main collection: 2775 received out of 3420 planned, including 160 unsent stage questions, 285 unsent prod questions and 200 unsent dev questions. Dev run 2 parallel-50 detected a closed prepared socket before the common start; dev run 6 repeats that cohort. Dev run 5 parallel-50 failed API login preparation, and dev run 7 repeats it. There are 925 received per group; five completed latency measurements per scenario. No group had five error-free original full matrices. This denominator includes recovery attempts and is not a production availability estimate.
Old-dev reference: 185 additional records. answers.csv includes all 3605 planned records, distinguished by group.
Fifteen successful preflight replies (including fresh controls after the incidents) are separate and excluded from latency metrics. The failed dev DNS preflight sent no questions.

Open report.html for the report; summary.md is the lightweight text alternative.
Import per-run.csv, pooled.csv, answers.csv or availability.csv into Google Sheets as separate sheets (UTF-8). validation.json records the final independent checks.
campaign.ipynb is an executed standard-library notebook. Run from this directory or the repository root.
Recompute with `python -X utf8 analyze.py` from this directory; build-report.py creates the canonical report payload/notebook.
Do not rerun run-campaign.py without a new task-specific output directory and an explicitly planned comparison.

Snapshots and client-source are preserved with SHA256. plan.json stores original run-1 sources and pinned client files;
inventory.json stores the 48 originally planned added scenario sources plus 10 supplemental stage/prod/dev sources. stage-incident.json and setup-failures.csv preserve preparation failures. manifest.sha256.json covers all archive files except itself.
The adjacent .zip.sha256 file hashes the entire ZIP. No outliers were removed or repeated to replace them.

Latency is websocket question send → complete assistant text, excluding setup and media.
Pooled p95 uses individual responses, never averages of p95s. Per-run results expose variability.
Client cacheEnabled=true does not identify cache hits; a nonce does not establish uncached LLM generation.
These are short 2-question bursts, not a sustained 50-user capacity/SLA test.
Compare stage/prod against themselves after a later deployment; cross-environment differences are not causal effects.
