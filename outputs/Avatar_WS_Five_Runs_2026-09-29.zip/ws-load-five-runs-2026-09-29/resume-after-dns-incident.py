"""Recover unsent cohorts after the observed ENOTFOUND incident; retain every failure."""
import importlib.util,json,shutil,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
assert json.loads((OUT/'state.json').read_text(encoding='utf-8'))['status']=='stopped'
spec=importlib.util.spec_from_file_location('campaign',OUT/'run-campaign.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base_env=m.env_for
fresh={'prod':'2026-09-29-five-runs-prod-after-dns-preflight','dev':'2026-09-29-five-runs-dev-after-dns-preflight'}
def env_for(env,run=None,mode=None):
 e=base_env(env,run,mode)
 if mode is None and env in fresh:e['WS_PREFLIGHT_RUN_ID']=fresh[env]
 return e
m.env_for=env_for
def supplemental(env,run,mode,scenarios):
 e=env_for(env,run,mode);e['WS_LOAD_SCENARIOS']=','.join(scenarios)
 root=m.ROOT/'test-results/ws-load'/e['WS_LOAD_RUN_ID']
 assert not root.exists(),'Refusing to overwrite '+str(root)
 m.emit(status='running',environment=env,group=m.GROUPS[env],run=run,mode='supplemental-'+mode,progress=None,error=None)
 code=m.child('playwright.ws-load.config.ts',e,f'{env}-r{run}-supplemental-{mode}.log')
 m.freeze(env,run,mode,root,expected=len(scenarios))
 m.state.setdefault('supplementalAttempts',[]).append({'group':m.GROUPS[env],'run':run,'mode':mode,'scenarios':scenarios,'exitCode':code,'atUtc':m.now()})
 m.emit(status='running',supplementalAttempts=m.state['supplementalAttempts'])
 # Do not proceed with repeated load if the connectivity failure persists.
 if code:raise RuntimeError('Supplemental cohort failed: '+env+' run '+str(run)+' '+mode)
try:
 failed=list((m.ROOT/'test-results/ws-preflight/2026-09-29-five-runs-dev-preflight').glob('*/preflight.json'))
 if failed:shutil.copyfile(failed[0],OUT/'preflight/dev-dns-failed.json')
 for env,label in [('prod','before-dns'),('stage','before-recovery')]:
  src=OUT/'preflight'/f'{env}.json';dest=OUT/'preflight'/f'{env}-{label}.json'
  if not dest.exists():shutil.copyfile(src,dest)
 prior=OUT/'plan-addendum-stage-only.json'
 if not prior.exists():shutil.copyfile(OUT/'plan-addendum.json',prior)
 m.save('plan-addendum.json',{'createdAtUtc':m.now(),'reason':'Stage run 5 preparation timeouts/HTTP 500; then prod run 4 parallel-50 and all run 5 failed DNS lookup. No measured questions were sent in failed cohorts. All failed outcomes retained.','additionalPlannedQuestions':445,'supplementalScenarios':8,'supplemental':[{'group':'prod-old','run':6,'scenarios':['chain-1x25','parallel-10','parallel-20','parallel-50']},{'group':'prod-old','run':7,'scenarios':['parallel-50']},{'group':'stage-old','run':6,'scenarios':['parallel-10','parallel-20','parallel-50']}],'target':'Five completed latency measurements per scenario, preserving failed preparations in all availability denominators.','orderAfterDns':'Fresh prod controls, prod recovery run 6 and run 7 parallel-50, fresh dev controls and its original runs 2–5, fresh stage controls and stage recovery run 6.','scopeDecision':'Continue the authorized five-measurement comparison after transient setup failures. Optional recovery preference offered earlier; no contrary preference received. No sent measured question is retried.','clientChanges':'None; original pinned measurement client/workload/settings remain unchanged.'})
 m.emit(status='running',error=None,progress=None)
 m.preflight('prod')
 supplemental('prod',6,'chain',['chain-1x25'])
 supplemental('prod',6,'parallel',['parallel-10','parallel-20','parallel-50'])
 supplemental('prod',7,'parallel',['parallel-50'])
 m.main()
 fresh['stage']='2026-09-29-five-runs-stage-recovery-preflight'
 m.preflight('stage')
 supplemental('stage',6,'parallel',['parallel-10','parallel-20','parallel-50'])
 m.emit(status='complete',finishedAtUtc=m.now(),note='All original attempts and separately identified recovery cohorts retained; final counts must be recomputed from snapshots.')
except BaseException as exc:
 m.state['errors'].append({'atUtc':m.now(),'error':str(exc)});m.emit(status='stopped',error=str(exc));sys.exit(1)
