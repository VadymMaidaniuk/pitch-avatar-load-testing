"""Preserve stage attempt 5, add a clearly separate recovery attempt, then continue."""
import importlib.util,json,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
initial=json.loads((OUT/'state.json').read_text(encoding='utf-8'))
assert initial['status']=='stopped','Wait for the original campaign process to finish first.'
spec=importlib.util.spec_from_file_location('campaign',OUT/'run-campaign.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
try:
 root=m.ROOT/'test-results/ws-load/2026-09-29-five-stage-r5-parallel'
 assert len(list(root.glob('artifacts/*/metrics/results.json')))==3
 m.freeze('stage',5,'parallel',root)
 phase='stage-old-r5-parallel'
 if phase not in m.state['completedPhases']:m.state['completedPhases'].append(phase)
 if 'stage-old-r5' not in m.state['finishedMatrices']:m.state['finishedMatrices'].append('stage-old-r5')
 m.state.setdefault('failedPhases',[]).append({'phase':phase,'atUtc':m.now(),'note':'Preparation failures retained. Original orchestration stopped; missing avatar metadata belongs to failed login sessions, not evidence of changed avatar settings.'})
 m.emit(status='running',error=None,completedPhases=m.state['completedPhases'],failedPhases=m.state['failedPhases'])
 addendum={'createdAtUtc':m.now(),'reason':'Stage run 5 parallel-10, parallel-20 and parallel-50 could not start full cohorts after setup timeouts/HTTP 500. Original outcomes remain in snapshots and all denominators.','supplementalGroup':'stage-old','supplementalRun':6,'scenarios':['parallel-10','parallel-20','parallel-50'],'additionalPlannedQuestions':160,'target':'Five completed latency samples per scenario, with preparation failures reported separately. This retries cohort preparation, not any sent measured question.','scopeDecision':'Optional question offered preserving failure plus one supplemental scenario as recommended. Failure expanded to all three parallel scenarios; no contrary user preference received, so the same recovery approach is applied to all three.','clientChanges':'None. Original pinned measurement client, workload and settings remain unchanged. Orchestration now retains failed outcomes instead of stopping the other environments.'}
 m.save('plan-addendum.json',addendum)
 # Stage is still intermittently timing out. Finish the independent prod/dev
 # matrices first, then make one clearly identified supplemental stage attempt.
 m.main()
 e=m.env_for('stage',6,'parallel')
 runroot=m.ROOT/'test-results/ws-load'/e['WS_LOAD_RUN_ID']
 assert not runroot.exists(),'Refusing to overwrite supplemental attempt'
 m.emit(status='running',environment='stage',group='stage-old',run=6,mode='supplemental-parallel',progress=None)
 code=m.child('playwright.ws-load.config.ts',e,'stage-old-r6-supplemental-parallel.log')
 m.freeze('stage',6,'parallel',runroot)
 m.state['supplementalAttempt']={'group':'stage-old','run':6,'exitCode':code,'atUtc':m.now(),'reason':addendum['reason']}
 m.emit(status='complete',supplementalAttempt=m.state['supplementalAttempt'],finishedAtUtc=m.now())
except BaseException as exc:
 m.state['errors'].append({'atUtc':m.now(),'error':str(exc)});m.emit(status='stopped',error=str(exc));sys.exit(1)
