"""Build a portable report and executed, dependency-free notebook after all matrices finish."""
import contextlib,io,json,math,sqlite3,statistics
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent
def read(name):return json.loads((OUT/name).read_text(encoding='utf-8'))
def save(name,obj):(OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
summary=read('summary.json');state=read('state.json')
assert summary['complete'] and state['status']=='complete'
assert summary['totals']['planned']==2775+read('plan-addendum.json')['additionalPlannedQuestions'] and summary['targetReplicationsReached'] and not summary['unknownAnswers']
GROUPS=['stage-old','prod-old','dev-new']
NAMES={'stage-old':'Stage — старий код','prod-old':'Prod — старий код','dev-new':'Dev — новий код','dev-old-reference':'Dev — старий код, один прогін'}
SCENARIOS={'chain-1x25':'1 × 25','parallel-10':'10 × 2','parallel-20':'20 × 2','parallel-50':'50 × 2'}
SQL="""WITH ranked AS (
 SELECT *,ROW_NUMBER() OVER (PARTITION BY group_id,run,scenario ORDER BY latency_ms,session,turn) AS rn,
 COUNT(*) OVER (PARTITION BY group_id,run,scenario) AS n
 FROM main.ws_answers WHERE status='ok'
) SELECT group_id,run,scenario,COUNT(*) AS answers,AVG(latency_ms)/1000.0 AS meanSeconds,
 MAX(CASE WHEN rn=CAST((n*95+99)/100 AS INTEGER) THEN latency_ms END)/1000.0 AS p95Seconds,
 MAX(latency_ms)/1000.0 AS maxSeconds
 FROM ranked GROUP BY group_id,run,scenario ORDER BY group_id,run,scenario;"""
(OUT/'per-run-metrics.sql').write_text(SQL,encoding='utf-8')
db=sqlite3.connect(OUT/'campaign.sqlite');db.row_factory=sqlite3.Row
native=[dict(x) for x in db.execute(SQL)];db.close()
for x in native:
 r=next(y for y in summary['perRun'] if (y['group'],y['run'],y['scenario'])==(x['group_id'],x['run'],x['scenario']))
 assert abs(x['meanSeconds']-r['meanMs']/1000)<1e-9 and abs(x['p95Seconds']-r['p95Ms']/1000)<1e-9
 x.update(runLabel=(('Додатковий '+str(x['run'])) if x['run']>5 else 'Прогін '+str(x['run'])),scenarioLabel=SCENARIOS[x['scenario']])
pooled=[x for x in summary['pooled'] if x['group'] in GROUPS]
totals=summary['totals'];now=datetime.now(timezone.utc).isoformat()
title='WS-навантаження: вимірювання та збої підготовки'
source={'id':'pooled','label':'Первинні відповіді, об’єднані за середовищем і сценарієм','path':'summary.json','query':{'engine':'SQLite','language':'sql','sql':(OUT/'pooled-metrics.sql').read_text(encoding='utf-8'),'tables_used':['campaign.sqlite: main.ws_answers'],'description':'analyze.py verifies frozen JSON hashes and imports every question into SQLite. Mean and nearest-rank percentiles use complete responses. Per-run mean ranges are independently recomputed from the same records. Exact paths and SHA256 are in plan.json and inventory.json.','filters':['Main comparison: stage-old, prod-old, dev-new, runs 1–5 plus separately identified stage run-6 parallel recovery, prod run-6 full recovery and prod run-7 parallel-50 recovery and dev runs 6 and 7 parallel-50 recovery. Failed original cohorts remain in the availability denominators. Old dev is a separate single-run reference.','Setup and preflight excluded. No outliers removed.'],'metric_definitions':['Full text latency: immediately before websocket.send to complete assistant text; seconds.','p95: nearest rank, ceil(0.95 × number of complete answers), pooled from raw answers, not an average of per-run percentiles.','Range: minimum and maximum of the five per-run means.']}}
run_source={'id':'runs','label':'Кожен прогін окремо','path':'per-run.csv','query':{'engine':'SQLite','language':'sql','sql':SQL,'tables_used':['campaign.sqlite: main.ws_answers'],'description':'Direct SQL aggregation by environment/code group, run and scenario; chart labels added without changing values.','filters':['Successful full-text responses. All five runs retained, including run 1 on the earlier date.'],'metric_definitions':['Mean complete-text response time in seconds, one bar per successfully completed scenario attempt; failed setup attempts have no latency bar.']}}
evidence_source={'id':'campaign','label':'Зафіксовані спроби, методика та діагностика','path':'summary.json','description':'Primary snapshots listed in plan.json and inventory.json with SHA256. Incident evidence: stage-incident.json, prod-dns-incident.json, dns-incident.json, dev-ws-incident.json, dev-login-incident.json, preflight/dev-dns-failed.json. Setup details: setup-failures.csv; client and workload: client-source/ and ws-load-aster-questions.json.'}
AVAILABILITY_SQL="""WITH cohorts AS (
 SELECT group_id,run,scenario,COUNT(*) AS planned,
 SUM(CASE WHEN status='ok' THEN 1 ELSE 0 END) AS complete,
 SUM(CASE WHEN status='skipped' THEN 1 ELSE 0 END) AS skipped
 FROM main.ws_answers WHERE group_id<>'dev-old-reference'
 GROUP BY group_id,run,scenario
) SELECT group_id,
 SUM(CASE WHEN run<=5 AND complete=planned THEN 1 ELSE 0 END) AS originalComplete,
 SUM(CASE WHEN run<=5 THEN 1 ELSE 0 END) AS originalAttempts,
 SUM(CASE WHEN run<=5 THEN skipped ELSE 0 END) AS unsent,
 SUM(CASE WHEN run>5 THEN complete ELSE 0 END) AS recoveryReplies
 FROM cohorts GROUP BY group_id ORDER BY group_id;"""
(OUT/'availability-metrics.sql').write_text(AVAILABILITY_SQL,encoding='utf-8')
availability_source={'id':'availability','label':'Початкові спроби та додаткові відповіді','path':'availability.csv','query':{'engine':'SQLite','language':'sql','sql':AVAILABILITY_SQL,'tables_used':['campaign.sqlite: main.ws_answers'],'description':'Executed cohort-level aggregation from the raw question table and checked against frozen JSON summaries. Human-readable group names added after aggregation.','filters':['Original attempts: runs 1–5. Recovery attempts: run > 5. Old-dev reference excluded.'],'metric_definitions':['Completed original scenario: complete reply count equals planned question count.','Unsent: original question rows with status skipped.']}}
datasets={};blocks=[];charts=[];tables=[]
def md(id,body,src=None):blocks.append({'id':id,'type':'markdown','body':body,**({'sourceId':src} if src else {})})
md('title','# '+title)
md('summary',f'## База для наступного порівняння готова\n\nПроведено **12 запланованих запусків матриці і десять додаткових сценаріїв** після збоїв підготовки stage, DNS на prod та закриття WebSocket на dev. Разом з попередніми отримано **по п’ять завершених вимірювань кожного сценарію і 925 відповідей на кожну групу**. Невдалі оригінальні спроби всіх трьох середовищ також збережено; жодна група не має п’яти безпомилкових початкових повних матриць.\n\nУ головній вибірці {totals["complete"]} завершених із {totals["planned"]} запланованих питань; {totals["correct"]} перевірених правильних, {totals["failed"]} помилок після надсилання, {totals["skipped"]} питань не надіслано через збої підготовки. Цей знаменник включає додаткові спроби і не є оцінкою доступності сервісу у звичайній роботі. Старий dev збережено окремо: один історичний прогін, 185 відповідей. П’ять прогонів дозволяють бачити розкид; вони не гарантують усунення аномалій.','pooled')
md('stage-incident','## Stage: невдала підготовка також є результатом тесту\n\nУ п’ятому stage-прогоні готовими стали 9/10, 9/20 та 46/50 сесій. Жодна з трьох паралельних груп не стартувала неповним складом; 160 запланованих питань не надсилалися. Було 49 невдалих спроб підготовки, зокрема 33 HTTP 500 на API login, а також таймаути входу, ініціалізації та WebSocket.\n\nОригінали збережено у run 5 і stage-incident.json. Окремий stage run 6 повторив лише ці три сценарії після тестів prod/dev. Він дає п’яті вимірювання часу, але не скасовує збій доступності. Ланцюг із 25 питань п’ятого stage-прогону завершився й не повторювався.','pooled')
md('dns-incident','## Prod: окремий збій DNS, а не виміряна затримка аватара\n\nПід час групи 50 четвертого prod-прогону клієнт почав отримувати API login: ENOTFOUND. У цій групі готовою була лише одна сесія; у п’ятому прогоні не підготувалася жодна. Разом 285 питань не надсилалися. Контроль dev також завершився ENOTFOUND до будь-якого питання.\n\nО 10:49:59 UTC окрема системна перевірка знову успішно визначила адреси всіх трьох API. Після нових контрольних відповідей виконано prod run 6 (повна матриця) і run 7 (лише 50 сесій). Джерело DNS-збою не встановлено; його не можна приписувати коду аватара. Діагностику збережено у prod-dns-incident.json, dns-incident.json та dev-dns-failed.json.','pooled')
md('dev-incident','## Dev: з’єднання закрилося до старту групи 50\n\nУ dev run 2 підготовка 50 сесій тривала близько 335 с. Усі сесії завершили підготовку, але перевірка перед спільним стартом виявила щонайменше один закритий WebSocket. Усі 100 питань цієї групи залишилися ненадісланими. Одна спроба API-входу під час підготовки отримала HTTP 500 і була успішно повторена.\n\nПричину та час закриття WebSocket не встановлено; це не виміряний таймаут відповіді аватара. Окремий dev run 6 повторив тільки групу 50. Первинний збій збережено у dev-ws-incident.json. У dev run 5 група 50 також не стартувала: одна сесія вичерпала спроби API-входу з HTTP 500. Ще 100 питань не надіслано; цей сценарій повторено окремо як dev run 7. Разом для dev збережено 200 ненадісланих питань із двох початкових невдалих груп.','pooled')
md('definition','## Що саме виміряно\n\nКожна матриця: одна сесія з 25 послідовними різними питаннями, потім 10, 20 і 50 незалежних сесій одного аватара, по два питання. Підготовка сесій послідовна, по одній одночасно, з максимум трьома спробами за тимчасових помилок; це налаштування однакове в усіх прогонах. Перша хвиля надсилається після готовності всіх сесій; друга — після першої відповіді у відповідній сесії. Це 25 + 20 + 40 + 100 = 185 вимірювань.\n\nТаймер — від відправлення питання через WebSocket до повного тексту відповіді. Вхід, підготовка з’єднання, контрольні питання, аудіо, відео та ліпсінк виключені. Мова англійська, джерело фактів — Aster Harbor Services у промпті. Паралельні питання №8 і №14 незмінні; у кожного повного запиту унікальний буквено-цифровий reference code. Вимірювані питання не повторювалися після помилок.','pooled')
md('reading','## Як читати результати\n\nСтовпчикові графіки показують середній час кожного завершеного сценарію окремого прогону; кольори розрізняють 1×25, 10×2, 20×2 і 50×2. Порожнє місце означає відсутність вимірювання, а не нуль секунд. Таблиці об’єднують сирі відповіді п’яти прогонів: по 125 для ланцюга, 100 для 10 сесій, 200 для 20 і 500 для 50. У стовпці «Розкид середніх» наведено мінімальне та максимальне середнє окремого прогону. p95 обчислено з усіх відповідей відповідного сценарію. Менше секунд — швидше.\n\nПрогін 1 для stage і prod виконано 28 вересня, прогони 2–5 — 29 вересня. Усі вимірювання dev із новим кодом виконано 29 вересня. Порядок цієї серії: stage → prod, додаткові сценарії prod після DNS-збою → dev → додаткові сценарії stage, потім два окремі повтори 50 сесій dev. Навантаження середовищ не накладалося. На графіках run 6 і run 7 позначено як додаткові. Для сценаріїв без надісланих питань немає точок часу відповіді; вони залишаються у таблиці спроб та діагностиці.','pooled')
availability=[]
for group in GROUPS:
 original=[r for r in summary['perRun'] if r['group']==group and r['run']<=5]
 recovery=[r for r in summary['perRun'] if r['group']==group and r['run']>5]
 availability.append({'group':NAMES[group],'originalComplete':sum(r['complete']==r['planned'] for r in original),'originalAttempts':len(original),'unsent':sum(r['skipped'] for r in original),'recoveryReplies':sum(r['complete'] for r in recovery)})
db=sqlite3.connect(OUT/'campaign.sqlite');db.row_factory=sqlite3.Row
for x in db.execute(AVAILABILITY_SQL):
 row=next(r for r in availability if r['group']==NAMES[x['group_id']])
 assert all(row[k]==x[k] for k in ['originalComplete','originalAttempts','unsent','recoveryReplies'])
db.close()
datasets['availability']=availability
md('availability-note','## Завершені вимірювання і невдалі запуски обліковано окремо\n\nПочаткові п’ять матриць дають 20 спроб сценаріїв на середовище. Таблиця показує, скільки з них завершилися, скільки питань залишилося ненадісланими та скільки відповідей отримано в окремо позначених додаткових запусках. Усі фактично надіслані вимірювані питання отримали правильні відповіді. Частка завершених спроб у цій невеликій серії не є оцінкою звичайної доступності сервісу.','campaign')
tables.append({'id':'availability-table','title':'Початкові спроби та додаткові відповіді','dataset':'availability','sourceId':'availability','columns':[{'field':f,'label':label,**({'type':'text'} if f=='group' else {'format':'number'})} for f,label in [('group','Група'),('originalComplete','Завершені сценарії'),('originalAttempts','Початкові спроби'),('unsent','Не надіслано питань'),('recoveryReplies','Додаткові відповіді')]]})
blocks.append({'id':'availability-table-block','type':'table','tableId':'availability-table'})
for group in GROUPS:
 rows=sorted([r for r in pooled if r['group']==group],key=lambda x:x['sessions']);fifty=next(r for r in rows if r['sessions']==50)
 md(group+'-claim','## '+NAMES[group]+f'\n\nДля 50 сесій загальне середнє — **{fifty["meanMs"]/1000:.3f} с**, p95 — **{fifty["p95Ms"]/1000:.3f} с**, максимум — **{fifty["maxMs"]/1000:.3f} с**. Середні п’яти окремих прогонів лежать у межах **{fifty["minRunMeanMs"]/1000:.3f}–{fifty["maxRunMeanMs"]/1000:.3f} с**. Усі повільні відповіді залишено в метриках.','pooled')
 datasets[group+'-runs']=[x for x in native if x['group_id']==group]
 datasets[group+'-pooled']=[{'scenario':SCENARIOS[r['scenario']],'answers':r['complete'],'meanSeconds':round(r['meanMs']/1000,3),'p95Seconds':round(r['p95Ms']/1000,3),'maxSeconds':round(r['maxMs']/1000,3),'range':f'{r["minRunMeanMs"]/1000:.3f}–{r["maxRunMeanMs"]/1000:.3f}'} for r in rows]
 charts.append({'id':group+'-chart','title':NAMES[group]+': середній час за прогоном','subtitle':'Секунди; чотири окремі сценарії, однакові питання та налаштування','showDescription':True,'type':'bar','settings':{'groupMode':'grouped'},'dataset':group+'-runs','sourceId':'runs','layout':'full','palette':{'kind':'categorical'},'encodings':{'x':{'field':'runLabel','type':'ordinal','label':'Прогін'},'y':{'field':'meanSeconds','type':'quantitative','label':'Секунди'},'color':{'field':'scenarioLabel','type':'nominal','label':'Сесій × питань'}}})
 blocks.append({'id':group+'-chart-block','type':'chart','chartId':group+'-chart'})
 tables.append({'id':group+'-table','title':NAMES[group]+': усі п’ять прогонів','dataset':group+'-pooled','sourceId':'pooled','columns':[{'field':f,'label':label,**({'type':'text'} if f in ['scenario','range'] else {'format':'number'})} for f,label in [('scenario','Сценарій'),('meanSeconds','Середнє, с'),('p95Seconds','p95, с'),('maxSeconds','Макс., с'),('range','Розкид середніх, с')]]})
 blocks.append({'id':group+'-table-block','type':'table','tableId':group+'-table'})
 old={r['scenario']:r for r in summary['pooled'] if r['group']=='dev-old-reference'}
 if group=='dev-new':
  changes='; '.join(f'{SCENARIOS[r["scenario"]]}: {old[r["scenario"]]["meanMs"]/1000:.3f} → {r["meanMs"]/1000:.3f} с ({(r["meanMs"]/old[r["scenario"]]["meanMs"]-1)*100:+.1f}%)' for r in rows)
  md('dev-reference','### Старий dev — тільки історичний орієнтир\n\nСередній час одного старого прогону → об’єднане середнє п’яти нових: '+changes+'.\n\nЦе нерівні за кількістю повторів вибірки. Старий код на dev уже замінено, тому п’ять старих прогонів відновити неможливо. Ці відсотки описові й не доводять причинний ефект змін.','pooled')
main=[r for r in summary['perRun'] if r['group'] in GROUPS]
fifties=[r for r in main if r['sessions']==50 and r['complete']>0]
md('concurrency',f'## Фактичну одночасність перевірено за інтервалами запитів\n\nДля кожної групи незалежно відновлено кількість одночасно незавершених запитів за часом надсилання й отримання відповіді. У 15 сценаріях на 50 сесій піки становлять **{min(r["peak"] for r in fifties)}–{max(r["peak"] for r in fifties)}**; час повної одночасності 50 — **{min(r["fullConcurrencySeconds"] for r in fifties):.3f}–{max(r["fullConcurrencySeconds"] for r in fifties):.3f} с**. Це короткі двохпитальні навантаження, а не тривала робота 50 користувачів.\n\nКлієнтська одночасність не показує кількість одночасних LLM-генерацій. Первинні таймінги, scrUserID, messageId та traceId збережено для зіставлення із серверними логами. Усі унікальні варіанти відповідей перевірено за ключем фактів; дослівно однакова відповідь на те саме змістовне питання успадковує перевірку.','pooled')
slow=sorted([r for r in read('summary.json')['perRun'] if r['group'] in GROUPS and r['maxMs'] is not None],key=lambda x:x['maxMs'],reverse=True)[0]
md('tails',f'## Максимуми збережено, аномалії не відкидалися\n\nНайдовша відповідь у головній вибірці — **{slow["maxMs"]/1000:.3f} с**, {NAMES[slow["group"]]}, прогін {slow["run"]}, сценарій {SCENARIOS[slow["scenario"]]}. Усі відповіді, включно з dev 21,54 с у першому прогоні, залишилися в даних. Вони впливають на середнє й максимум, навіть коли не змінюють p95.','pooled')
md('limits','## Що ця база поки не доводить\n\nМітки «старий» та «новий» спираються на повідомлення користувача. Commit або build ID бекенду не надано, тому версію розгортання незалежно не підтверджено. Збережений git SHA належить тестовому клієнту.\n\nAPI аватара повідомляє cacheEnabled=true. Унікальний reference code не гарантує cache miss. Серверні cache hit/miss, час черги, LLM-таймінги, версія моделі та фонове навантаження не вимірювалися. Збережені метадані аватара та налаштування клієнта збігаються з першим прогоном відповідної групи.\n\nП’ять повторів дають описову оцінку розкиду для цих запусків. Середовища можуть відрізнятися ресурсами й фоновою активністю: порівняння нового dev зі старими stage/prod не ізолює вплив коду. Для висновку про розгортання треба порівняти stage і prod із самими собою після оновлення, зберігши навантаження та налаштування.')
md('next','## Що зафіксовано для наступного етапу\n\nplan.json та inventory.json містять шляхи й SHA256 незмінних первинних результатів; snapshots/ — їхні копії. per-run.csv містить кожен сценарій кожного прогону, pooled.csv — зведення, answers.csv — питання, відповіді й таймінги. campaign.ipynb відтворює перевірки й агрегацію без мережі. ZIP-архів і SHA256-маніфест фіксують цю версію бази.\n\nПісля повідомлення про розгортання на stage/prod можна виконати таку саму серію нового коду й порівняти всередині кожного середовища. У поточній серії новий код stage/prod не тестувався.')
for block in blocks:
 if block['id'] in ['summary','stage-incident','dns-incident','dev-incident','definition','reading','concurrency','tails']:
  block['sourceId']='campaign'
artifact={'surface':'report','manifest':{'version':1,'surface':'report','title':title,'generatedAt':now,'sources':[source,run_source,evidence_source,availability_source],'blocks':blocks,'charts':charts,'tables':tables},'snapshot':{'version':1,'status':'ready','generatedAt':now,'datasets':datasets},'sources':[source,run_source,evidence_source,availability_source]}
save('artifact.json',artifact)
save('report-notes.json',{'audience':'technical baseline for future deployment comparison','surface':'portable HTML; no external publication requested','chartContract':{'family':'three native grouped bar charts, one per environment/code group','rows':'five completed observations per scenario; original failed preparations remain without latency points; separately labeled recovery runs','metric':'mean full-text response time, seconds','encoding':'ordered run on x, seconds on y, scenario color with legend','interpretation':'Descriptive variability; run spacing is ordinal, not elapsed time. Grouped bars preserve isolated successful recoveries and historical observations across failed-cohort gaps. No causal cross-environment comparison.'},'omissions':'No cache hit rate, server LLM concurrency, sustained capacity, SLA or causal deployment effect. No confidence interval from five sequential convenience samples.','requiredStructure':{'technicalSummary':'summary','findings':'stage-old/prod-old/dev-new claims, charts and tables','scopeAndDefinitions':'definition and reading','methodology':'definition and concurrency','limitationsAndRobustness':'incidents, tails, dev-reference and limits','nextSteps':'next','furtherQuestions':'limits: backend version, cache, queue and LLM evidence needed'},'qa':'Pending official portable delivery and visual inspection.'})
mdlines=['# '+title,'',f'Проведено 12 запланованих запусків матриці і 10 окремих відновлювальних сценаріїв stage/prod/dev. Разом по 5 завершених вимірювань кожного сценарію stage-old, prod-old, dev-new: {totals["complete"]}/{totals["planned"]} завершено, {totals["correct"]} правильно.','', '| Група | Сценарій | Середнє, с | p95, с | Максимум, с | Межі середніх 5 прогонів, с |','|---|---|---:|---:|---:|---|']
for g in GROUPS:
 for r in sorted([x for x in pooled if x['group']==g],key=lambda x:x['sessions']):mdlines.append(f'| {NAMES[g]} | {SCENARIOS[r["scenario"]]} | {r["meanMs"]/1000:.3f} | {r["p95Ms"]/1000:.3f} | {r["maxMs"]/1000:.3f} | {r["minRunMeanMs"]/1000:.3f}–{r["maxRunMeanMs"]/1000:.3f} |')
mdlines+=['','У 10 початкових сценаріях підготовка не дозволила надіслати 645 питань: stage 160, prod 285, dev 200. Усі ці спроби збережено. Додаткові сценарії забезпечують п’яті вимірювання часу, але не скасовують збої. Це не п’ять безпомилкових початкових матриць.','','Старий dev збережено окремо: один прогін. Усі повільні відповіді включено. Мітки версій — за повідомленням користувача; кеш увімкнений, cache hit/miss невідомі. Stage/prod зафіксовано для порівняння після розгортання.','', 'Повний звіт: report.html. Питання й відповіді: answers.csv. Розклад за прогонами: per-run.csv. Зведення: pooled.csv.']
(OUT/'summary.md').write_text('\n'.join(mdlines)+'\n',encoding='utf-8')

# nbformat/nbclient are absent. Use standard nbformat v4 JSON, validate structure,
# and execute every code cell top to bottom in one namespace, preserving stdout.
cells=[]
def markdown(id,text):cells.append({'cell_type':'markdown','id':id,'metadata':{},'source':text.splitlines(True)})
def code(id,text):cells.append({'cell_type':'code','id':id,'metadata':{},'source':text.splitlines(True),'execution_count':None,'outputs':[]})
markdown('tldr','# Five-run WebSocket campaign\n\nStage old, prod old and dev new: five completed latency measurements per scenario. Stage run 5 failed preparation for 10/20/50 (160 unsent questions). Prod run 4 parallel-50 and run 5 failed DNS lookup (285 unsent questions). Dev run 2 parallel-50 detected a closed prepared WebSocket before the common start (100 unsent). Dev run 5 parallel-50 failed API login preparation (100 unsent). All failures remain; recovery cohorts are separately identified as stage run 6, prod run 6, prod run 7 parallel-50 and dev runs 6 and 7 parallel-50. Old dev: one separate historical matrix. This notebook verifies the frozen inputs and recomputes descriptive results. It uses only the Python standard library and performs no network calls.\n')
markdown('methods','## Context and methods\n\nEach matrix is 1×25, 10×2, 20×2, 50×2. Latency is question send → full assistant text; setup/media/control replies excluded. Nearest-rank p95 is computed from individual replies. No outliers are removed.\n\n### Key assumptions\nOld/new backend labels are user-reported; runner git SHA is not a backend release. Cache is enabled and a unique nonce does not prove a cache miss. Cross-environment differences are not causal code effects.\n')
markdown('data-title','## Data\n\nFrozen result JSON files are listed with SHA256 in plan.json and inventory.json. campaign.sqlite is a derived local database; summary.json and the CSV files are derived outputs. No external data are fetched.\n')
code('data',"""from pathlib import Path
import hashlib,json,sqlite3,statistics,math
BASE=Path.cwd() if Path('plan.json').exists() else Path.cwd()/'test-results/ws-load-five-runs-2026-09-29'
def read(name):return json.loads((BASE/name).read_text(encoding='utf-8'))
plan=read('plan.json');inventory=plan['snapshots']+read('inventory.json');summary=read('summary.json')
for entry in inventory:
    assert hashlib.sha256((BASE/entry['snapshot']).read_bytes()).hexdigest()==entry['sha256']
assert len(inventory)==64+read('plan-addendum.json')['supplementalScenarios'] and summary['complete'] and summary['targetReplicationsReached']
print('Verified',len(inventory),'frozen scenario snapshots; 60 completed main scenarios plus all failed preparation scenarios and 4 old-dev reference.')
print(json.dumps(summary['totals'],indent=2))
""")
markdown('results-title','## Results\n\nCounts and percentiles below are recalculated from frozen JSON and checked against the saved SQLite aggregates.\n')
code('recompute',"""raw={}
for entry in inventory:
    doc=read(entry['snapshot'])
    key=(entry['group'],entry['scenario'])
    raw.setdefault(key,[]).extend(q['reply']['fullTextMs'] for q in doc['questions'] if q['status']=='ok')
db=sqlite3.connect(BASE/'campaign.sqlite');db.row_factory=sqlite3.Row
for row in db.execute((BASE/'pooled-metrics.sql').read_text(encoding='utf-8')):
    a=sorted(raw[(row['groupId'],row['scenario'])])
    assert len(a)==row['complete']
    for actual,expected in [(statistics.mean(a),row['meanMs']),(a[math.ceil(.5*len(a))-1],row['p50Ms']),(a[math.ceil(.95*len(a))-1],row['p95Ms']),(max(a),row['maxMs'])]:
        assert abs(actual-expected)<1e-6
    print(row['groupId'],row['scenario'],'n=',len(a),'mean=',round(row['meanMs']/1000,3),'p95=',round(row['p95Ms']/1000,3),'max=',round(row['maxMs']/1000,3))
""")
code('run-spread',"""for group in ['stage-old','prod-old','dev-new']:
    runs=[r for r in summary['perRun'] if r['group']==group and r['sessions']==50 and r['complete']>0]
    assert len(runs)==5 and all(r['peak']==50 for r in runs)
    print(group,'50 sessions mean by run:',[round(r['meanMs']/1000,3) for r in runs])
    print('Full 50-request overlap, seconds:',[round(r['fullConcurrencySeconds'],3) for r in runs])
db.close()
""")
markdown('takeaways','## Takeaways\n\nThe baseline is frozen for a later within-environment comparison after deployment. The data retain 645 unsent questions from ten failed stage/prod/dev preparation cohorts. Supplemental runs supply missing usable latency measurements and do not erase availability failures. Five runs expose variability; they do not eliminate anomalies or prove sustained capacity. All outliers remain, including the 21.54-second dev-new run-1 reply. Old dev has only one reference run. See report.html for charts, per-run.csv for all scenarios, and answers.csv for complete request/response evidence.\n')
namespace={};count=0
for cell in cells:
 if cell['cell_type']=='code':
  count+=1;buf=io.StringIO()
  with contextlib.redirect_stdout(buf):exec(compile(''.join(cell['source']),'campaign.ipynb:'+cell['id'],'exec'),namespace)
  cell['execution_count']=count;cell['outputs']=[{'output_type':'stream','name':'stdout','text':buf.getvalue().splitlines(True)}]
assert len({c['id'] for c in cells})==len(cells)
save('campaign.ipynb',{'nbformat':4,'nbformat_minor':5,'metadata':{'kernelspec':{'display_name':'Python 3','language':'python','name':'python3'},'language_info':{'name':'python','version':'3'},'execution_validation':'Every code cell executed top to bottom by the standard-library generator; nbformat/nbclient unavailable.'},'cells':cells})
print('Created artifact.json, summary.md and executed campaign.ipynb.')
