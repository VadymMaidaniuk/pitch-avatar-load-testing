"""Recompute every frozen result and pooled five-run metrics; no network access."""
import csv,hashlib,json,math,sqlite3,statistics
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def save(name,data):
 temp=OUT/(name+'.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(OUT/name)
def digest(q,t):return hashlib.sha256(f'{q}\n{t}'.encode()).hexdigest()
def quantiles(values):
 a=sorted(values)
 return dict(count=len(a),meanMs=statistics.mean(a) if a else None,p50Ms=a[math.ceil(len(a)*.5)-1] if a else None,p95Ms=a[math.ceil(len(a)*.95)-1] if a else None,maxMs=max(a) if a else None)
def analyze():
 plan=read(OUT/'plan.json');inventory=plan['snapshots']+(read(OUT/'inventory.json') if (OUT/'inventory.json').exists() else [])
 assert len({x['snapshot'] for x in inventory})==len(inventory)
 ledger=read(OUT/'reviewed-answers.json');key=read(OUT/'ws-load-aster-answer-key.json')
 per_run=[];answers=[];setup_rows=[];session_ids=set();question_texts=set();unknown={};baseline={};all_values=defaultdict(list)
 db=sqlite3.connect(OUT/'campaign.sqlite');db.row_factory=sqlite3.Row
 db.execute('CREATE TABLE IF NOT EXISTS ws_answers (group_id TEXT, environment TEXT, code_label TEXT, run INTEGER, scenario TEXT, sessions INTEGER, session INTEGER, turn INTEGER, status TEXT, quality TEXT, latency_ms REAL, PRIMARY KEY(group_id,run,scenario,session,turn))')
 db.execute('DELETE FROM ws_answers')
 for source in sorted(inventory,key=lambda x:(x['group'],x['run'],x['scenario'])):
  p=OUT/source['snapshot'];assert hashlib.sha256(p.read_bytes()).hexdigest()==source['sha256'],'Frozen snapshot changed'
  d=read(p);group=source['group'];run=source['run'];scenario=d['scenario']['name'];n=d['scenario']['sessions'];s=d['summary'];cache=Counter()
  assert d['environment']==source['environment'] and scenario==source['scenario']
  assert len(d['questions'])==s['plannedQuestions']==n*d['scenario']['questions']
  assert len({(q['session'],q['turn']) for q in d['questions']})==len(d['questions'])
  if run==1:baseline[(group,scenario)]=d
  else:
   b=baseline[(group,scenario)]
   for field in ['questionsSha256','comparableQuestionCasesSha256','requestedLanguageId','parallelQuestionIds','setupTimeoutMs','setupConcurrency','setupAttemptLimit','connectTimeoutMs','responseTimeoutMs','startupQuietMs','requireCacheDisabled','retries','percentileMethod']:
    assert d['settings'][field]==b['settings'][field],(group,run,scenario,field)
   assert all(m['avatar'] is None or m['avatar']==b['sessions'][0]['avatar'] for m in d['sessions'])
  for session in d['sessions']:
   if session['ready']:
    identity=(source['environment'],session['scrUserID']);assert identity not in session_ids;session_ids.add(identity)
   cache[str((session['avatar'] or {}).get('cacheEnabled'))]+=1
   for attempt in session.get('preparationAttempts',[]):
    if not attempt['ready']:setup_rows.append(dict(group=group,environment=source['environment'],run=run,scenario=scenario,session=session['session'],**attempt))
  values=[];events=[];quality=Counter();messages=[]
  for q in d['questions']:
   assert q['question'] not in question_texts;question_texts.add(q['question'])
   r=q['reply'] or {};text=r.get('text','');h=digest(q['sourceQuestionId'],text)
   grade=ledger.get(h,{}).get('assessment','unreviewed') if q['status']=='ok' else 'transport_'+q['status'];quality[grade]+=1
   if grade=='unreviewed':unknown[h]=dict(sourceQuestionId=q['sourceQuestionId'],text=text,expected=key['questions'][q['sourceQuestionId']-1]['expectedAnswer'])
   if q['status']=='ok':
    assert 0<=r['firstTextMs']<=r['fullTextMs']==r['elapsedMs'];values.append(r['fullTextMs']);messages.append(r['messageId'])
   if r:events.extend([(r['sentAtMonotonicMs'],1),(r['sentAtMonotonicMs']+r['elapsedMs'],-1)])
   db.execute('INSERT INTO ws_answers VALUES (?,?,?,?,?,?,?,?,?,?,?)',(group,source['environment'],source['codeLabel'],run,scenario,n,q['session'],q['turn'],q['status'],grade,r.get('fullTextMs')))
   answers.append(dict(group=group,environment=source['environment'],codeLabel=source['codeLabel'],run=run,scenario=scenario,session=q['session'],scrUserID=q['scrUserID'],turn=q['turn'],questionId=q['sourceQuestionId'],status=q['status'],quality=grade,sentAtUtc=r.get('sentAtUtc'),fullTextMs=r.get('fullTextMs'),firstTextMs=r.get('firstTextMs'),messageId=r.get('messageId'),traceId=r.get('traceId'),question=q['question'],answer=text,error=q['error']))
  assert len(messages)==len(set(messages))
  calc=quantiles(values)
  for k,v in calc.items():assert v==s['fullText'][k] if v is None else abs(v-s['fullText'][k])<1e-6
  assert len(values)==s['successfulQuestions']
  active=peak=0;full=area=0.;events.sort();prev=events[0][0] if events else 0
  for t,delta in events:
   duration=t-prev;area+=active*duration
   if active==n:full+=duration
   active+=delta;peak=max(peak,active);prev=t
  assert active==0 and peak==s['peakInFlight']
  window=events[-1][0]-events[0][0] if events else 0
  first=[q['reply'] for q in d['questions'] if q['turn']==1 and q['reply']]
  row=dict(group=group,environment=source['environment'],codeLabel=source['codeLabel'],run=run,scenario=scenario,sessions=n,planned=s['plannedQuestions'],complete=s['successfulQuestions'],correct=quality['correct'],failed=s['failedQuestions'],skipped=s['skippedQuestions'],unreviewed=quality['unreviewed'],**calc,peak=peak,fullConcurrencySeconds=full/1000,responseWindowSeconds=window/1000,meanOutstanding=area/window if window else None,sendSpreadMs=s['firstWaveSendSpreadMs'],allFirstSentBeforeFirstReplyMs=min(x['sentAtMonotonicMs']+x['elapsedMs'] for x in first)-max(x['sentAtMonotonicMs'] for x in first) if first else None,setupFailedAttempts=s['failedSetupAttempts'],readySessions=s['readySessions'],setupWallSeconds=s['setupWallMs']/1000,cohortError=s['cohortError'],cacheEnabledSessions=cache['True'],cacheDisabledSessions=cache['False'],startedAtUtc=d['startedAtUtc'],finishedAtUtc=d['finishedAtUtc'],sourceSnapshot=source['snapshot'])
  per_run.append(row);all_values[(group,scenario)].extend(values)
 db.commit()
 sql='''WITH ranked AS (
  SELECT *,ROW_NUMBER() OVER (PARTITION BY group_id,scenario ORDER BY latency_ms,run,session,turn) AS rn,
  COUNT(*) OVER (PARTITION BY group_id,scenario) AS n FROM main.ws_answers WHERE status='ok'
 ) SELECT group_id AS groupId,environment,code_label AS codeLabel,scenario,sessions,COUNT(*) AS complete,
 AVG(latency_ms) AS meanMs,
 MAX(CASE WHEN rn=CAST((n*50+99)/100 AS INTEGER) THEN latency_ms END) AS p50Ms,
 MAX(CASE WHEN rn=CAST((n*95+99)/100 AS INTEGER) THEN latency_ms END) AS p95Ms,MAX(latency_ms) AS maxMs
 FROM ranked GROUP BY group_id,environment,code_label,scenario,sessions ORDER BY group_id,sessions;'''
 (OUT/'pooled-metrics.sql').write_text(sql,encoding='utf-8')
 pooled=[]
 for result in db.execute(sql):
  row=dict(result);group=row.pop('groupId');row['group']=group;cases=[x for x in per_run if x['group']==group and x['scenario']==row['scenario']];calculated=quantiles(all_values[(group,row['scenario'])])
  for k in ['meanMs','p50Ms','p95Ms','maxMs']:assert abs(row[k]-calculated[k])<1e-6
  means=[x['meanMs'] for x in cases if x['meanMs'] is not None]
  row.update(runs=sum(x['complete']>0 for x in cases),attempts=len(cases),runNumbers=','.join(str(x['run']) for x in cases),measuredRunNumbers=','.join(str(x['run']) for x in cases if x['complete']>0),planned=sum(x['planned'] for x in cases),correct=sum(x['correct'] for x in cases),failed=sum(x['failed'] for x in cases),skipped=sum(x['skipped'] for x in cases),unreviewed=sum(x['unreviewed'] for x in cases),minRunMeanMs=min(means),medianRunMeanMs=statistics.median(means),maxRunMeanMs=max(means),stdevRunMeanMs=statistics.stdev(means) if len(means)>1 else None)
  pooled.append(row)
 main=[x for x in per_run if x['group']!='dev-old-reference'];complete_groups={}
 for group in ['stage-old','prod-old','dev-new']:
  complete_groups[group]=[r for r in range(1,6) if len([x for x in main if x['group']==group and x['run']==r])==4]
 addendum=read(OUT/'plan-addendum.json') if (OUT/'plan-addendum.json').exists() else {}
 extra=addendum.get('additionalPlannedQuestions',0)
 required=addendum.get('supplemental',[{'group':'stage-old','run':6,'scenarios':['parallel-10','parallel-20','parallel-50']}] if extra else [])
 supplemental_recorded=all(any(x['group']==r['group'] and x['run']==r['run'] and x['scenario']==case for x in main) for r in required for case in r['scenarios'])
 finished=all(len(v)==5 for v in complete_groups.values()) and supplemental_recorded
 complete_measurements={g:[r for r in complete_groups[g] if all(x['complete']==x['planned'] for x in main if x['group']==g and x['run']==r)] for g in complete_groups}
 replications={g:{case:sorted(r['run'] for r in main if r['group']==g and r['scenario']==case and r['complete']==r['planned']) for case in ['chain-1x25','parallel-10','parallel-20','parallel-50']} for g in complete_groups}
 summary=dict(generatedAtUtc=datetime.now(timezone.utc).isoformat(),complete=finished,versionEvidence=plan['versionEvidence'],completeGroups=complete_groups,completeMeasurementGroups=complete_measurements,completeScenarioReplications=replications,targetReplicationsReached=all(len(v)==5 for g in replications.values() for v in g.values()),totals=dict(planned=sum(x['planned'] for x in main),complete=sum(x['complete'] for x in main),correct=sum(x['correct'] for x in main),failed=sum(x['failed'] for x in main),skipped=sum(x['skipped'] for x in main),unreviewed=sum(x['unreviewed'] for x in main)),perRun=per_run,pooled=pooled,sources=inventory,excluded=plan['excluded'],unknownAnswers=unknown)
 if finished:
  assert summary['totals']['planned']==2775+extra and len(main)==60+sum(len(r['scenarios']) for r in required)
 save('summary.json',summary)
 save('slowest-responses.json',sorted([x for x in answers if x['group']!='dev-old-reference' and x['status']=='ok'],key=lambda x:x['fullTextMs'],reverse=True)[:10])
 for name,rows in [('per-run.csv',per_run),('pooled.csv',pooled),('answers.csv',answers),('setup-failures.csv',setup_rows)]:
  if not rows:continue
  with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
   writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader()
   for row in rows:writer.writerow({k:("'"+v if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')) else v) for k,v in row.items()})
 db.close();return summary
if __name__=='__main__':
 s=analyze();print(json.dumps({'completeGroups':s['completeGroups'],'totals':s['totals'],'unknownAnswers':s['unknownAnswers']},ensure_ascii=False,indent=2))
